/*
    File:  ecu1_main.c
    NAME : ABISHEK C
    PROJECT : CAN BASED AUTOMATION DASHBOARD [ECU1]
 */

#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "digital_keypad.h"
#include "msg_id.h"
#include "clcd.h"
void init_config(void)
{
    init_adc();
    init_clcd();
//    init_matrix_keypad();
    init_digital_keypad();
    init_can();
}
uint16_t msg_id,len;
uint8_t data[3];
int main()
{
    //Call the functions
    init_config();
    while(1)
    {
        get_gear_pos();
        get_speed();
    }        
}