#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "clcd.h"
#include "digital_keypad.h"

uint8_t data[3];
void get_speed(void)
{
    int speed =((float)read_adc(CHANNEL4)/1023)*99;
    data[0] = speed / 10 + 48;
    data[1] =speed % 10 + 48;
    data[2]='\0';
    can_transmit(SPEED_MSG_ID,data,3);
    __delay_ms(1000);
}

char ev[9][3] = {"ON","GN","G1","G2","G3","G4","G5","GR","C_"};
void get_gear_pos(void)
{
    // Implement the gear function
    unsigned char key;
    static unsigned int ind = 0;
    key = read_digital_keypad(STATE_CHANGE);
    if(key == SWITCH1)
    {
        if(ind < 7)
        {
            ind++;
        }
        else if(ind == 8)
        {
            ind = 1;
        }
        else
        {
            ind = 7;
        }
    }
    else if(key == SWITCH2)
    {
        if(ind == 8)
        {
            ind = 1;
        }
        if(ind > 1)
        {
            ind--;
        }
        else
        {
            ind = 1;
        }
    }
    else if(key == SWITCH3)
    {
        ind = 8; 
    }
    data[0]=ev[ind][0];
    data[1]=ev[ind][1];
    data[2]='\0';
    can_transmit(GEAR_MSG_ID,data,3);
    __delay_ms(1000);
}