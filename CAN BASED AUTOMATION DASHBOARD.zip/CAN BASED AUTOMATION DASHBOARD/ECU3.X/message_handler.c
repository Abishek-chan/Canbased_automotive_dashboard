#include <xc.h>
#include <string.h>
#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"

uint16_t msg_id,len;
uint8_t data[5];

volatile unsigned char led_state = LED_OFF, status = e_ind_off;


void handle_speed_data(uint8_t *data, uint8_t len)
{
    //Implement the speed function
    clcd_print(data,LINE2(0));
}

void handle_gear_data(uint8_t *data, uint8_t len) 
{
    //Implement the gear function
    clcd_print(data,LINE2(4));
    
}

void handle_rpm_data(uint8_t *data, uint8_t len) 
{
    //Implement the rpm function
    clcd_print(data,LINE2(8));
}

void handle_engine_temp_data(uint8_t *data, uint8_t len) 
{
    //Implement the temperature function
}

void handle_indicator_data(uint8_t *data, uint8_t len) 
{
    //Implement the indicator function
    clcd_print(data,LINE2(13));
    
    unsigned char key;
    unsigned int delay = 5000;
    
    if(data[0] == '1')
    {
        clcd_print("<- ",LINE2(13));
        LEFT_IND_ON();
        __delay_ms(500);
        clcd_print("   ",LINE2(13));
        LEFT_IND_OFF();
        __delay_ms(500);
    }
    else if(data[0] == '2')
    {
        clcd_print("-> ",LINE2(13));
        RIGHT_IND_ON();
        __delay_ms(500);
        clcd_print("   ",LINE2(13));
        RIGHT_IND_OFF();
        __delay_ms(500);
    }
    else
    {
        clcd_print("OFF",LINE2(13));
        PORTB = LED_OFF;
    }
}

void process_canbus_data() 
{   
    //process the CAN bus data
    can_receive(&msg_id,data,&len);
    clcd_print("SP  GR  RPM  IND",LINE1(0));
    if(RPM_MSG_ID == msg_id)
    {
       handle_rpm_data(data,len);
    }
    else if(SPEED_MSG_ID == msg_id)
    {
        handle_speed_data(data,len);
    }
    else if(GEAR_MSG_ID  == msg_id)
    {
        handle_gear_data(data,len); 
    }
    else if(INDICATOR_MSG_ID  == msg_id)
    {
        handle_indicator_data(data,len);
    }
}