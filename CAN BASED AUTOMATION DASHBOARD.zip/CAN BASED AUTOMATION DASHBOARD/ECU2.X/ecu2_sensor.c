#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "digital_keypad.h"
#include "clcd.h"
uint8_t data[5];
void get_rpm()
{
    //Implement the rpm function
    int RPM = ((float)read_adc(CHANNEL4)/1023) * 6000;
    data[0] = ((RPM / 1000) % 10) + 48;
    data[1] =((RPM / 100) % 10) + 48;
    data[2]=  ((RPM / 10) % 10) + 48;
    data[3]=  (RPM % 10) + 48;
    data[4]='\0';
    can_transmit(RPM_MSG_ID,data,5);
    __delay_ms(1000);
}


uint16_t get_engine_temp()
{
    //Implement the engine temperature function
}

//IndicatorStatus process_indicator()
static unsigned char flag = '0';
void process_indicator(void)
{
    //Implement the indicator function
    unsigned char key;
    unsigned int delay = 5000;
    key = read_digital_keypad(STATE_CHANGE);
    if(key == SWITCH1)
    {
        flag = '1';
    }
    else if(key == SWITCH2)
    {
        flag = '0';
    }
    else if(key == SWITCH3)
    {
        flag = '2';
    }
    data[0] = flag;
    data[1] = '\0';

    can_transmit(INDICATOR_MSG_ID,data,2);
    __delay_ms(1000);
}