/*
 *  File:  ecu2_main.c
 *  NAME : ABISHEK C
 *  PROJECT : CAN BASED AUTOMATION DASHBOARD [ECU2]
 */


#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "digital_keypad.h"
#include "clcd.h"

void init_config(void)
{
    PORTB = 0x00;
    TRISB = 0x08;
    init_can();
    init_adc();
    init_clcd();
    init_digital_keypad();
}
int main()
{
    //Call the functions
    init_config();
    while(1)
    {
        get_rpm();
        process_indicator();
    }
        
}